Plugins for individual text editors are kept in separate subfolders within this directory. 
