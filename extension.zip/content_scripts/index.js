

(function startIoConnect() {
    if (!window) {
        console.log("wasn't ready")
        setTimeout(startIoConnect,1000)
    }
    console.log("ready")
    window.addEventListener("message",(e)=> {
        if (e.source== window && e.data && e.data.direction=="iodide-to-extension"){
            console.log("received object from window in extension")
            console.log(e)
            console.log(e.data.message)
            // need to try getting the port out of this and communicating to the editor
        }
})
})()
