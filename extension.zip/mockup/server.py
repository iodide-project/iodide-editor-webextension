## responsiblities  of the server
# send these types
# { type: “REPLACE_ALL_JSMD”, textContent }
# { type: “INSERT_TEXT”, cursorPosition, text }
# { type: “DELETE_TEXT”, cursorPosition, numCharsToDelete }
# { type: “EVALUATE_CHUNK”, cursorPosition }
# ? question might be what is a good exchange, should it be single characters?
# ? the other issue is that in many editors text can be added or deleted in larger sections than one character at a time, perhaps every now and then the 
# ? or the server can have a copy of what it thinks the client version is, and 
# ? something is needed to prompt the server in this mock example, could use thread to put server serve forever in the background
# ? see if there's a way to tune into nvim events without actually going through plugin install stuff and all that

from SimpleWebSocketServer import SimpleWebSocketServer, WebSocket
import threading
import time
import json

def startinback():
    server.serveforever()



connection = []
class SimpleEcho(WebSocket):
    def handleMessage(self):
        # echo message back to client
        self.sendMessage(self.data+" serverfile")
        print("handling response")
        self.options(self.data)
    def handleConnected(self):
        print(self.address, 'connected')
        connection.append(self)
    def handleClose(self):
        print(self.address, 'closed')
    def options(self,d):
        ## use this for splitting into the various response options
        info = json.loads(d)
        if info["type"] == "io_update":
            print("changing file text to {}".format(info["content"]))



server = SimpleWebSocketServer('', 8000, SimpleEcho)
x = threading.Thread(target=startinback)
x.start()

con = connection[-1]
packet = json.dumps({"type":"REPLACE_ALL_JSMD","content":"whole document goes away"})
con.sendMessage(packet)

# x.join()
server.close()

